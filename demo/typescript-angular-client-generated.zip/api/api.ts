export * from './employee.service';
import { EmployeeService } from './employee.service';
export const APIS = [EmployeeService];
