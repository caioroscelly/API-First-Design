package io.swagger.api;

import io.swagger.api.*;
import io.swagger.model.*;


import io.swagger.model.Employee;

import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2018-06-07T10:54:23.419Z")
public abstract class FindEmployeeDetailsApiService {
      public abstract Response getEmployeeDetails(Long employeeId,SecurityContext securityContext)
      throws NotFoundException;
}
