package io.swagger.api;

import io.swagger.model.*;
import io.swagger.api.FindEmployeeDetailsApiService;
import io.swagger.api.factories.FindEmployeeDetailsApiServiceFactory;

import io.swagger.annotations.ApiParam;
import io.swagger.jaxrs.*;

import io.swagger.model.Employee;

import java.util.Map;
import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.validation.constraints.*;

@Path("/findEmployeeDetails")


@io.swagger.annotations.Api(description = "the findEmployeeDetails API")
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2018-06-07T10:54:23.419Z")
public class FindEmployeeDetailsApi  {
   private final FindEmployeeDetailsApiService delegate = FindEmployeeDetailsApiServiceFactory.getFindEmployeeDetailsApi();

    @GET
    @Path("/{employeeId}")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Find employee by ID", notes = "Returns a single Employee", response = Employee.class, tags={ "employee", })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "successful operation", response = Employee.class),
        
        @io.swagger.annotations.ApiResponse(code = 400, message = "Invalid Employee ID supplied", response = Void.class),
        
        @io.swagger.annotations.ApiResponse(code = 404, message = "Employee not found", response = Void.class) })
    public Response getEmployeeDetails( @PathParam("employeeId") Long employeeId,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getEmployeeDetails(employeeId,securityContext);
    }
}
