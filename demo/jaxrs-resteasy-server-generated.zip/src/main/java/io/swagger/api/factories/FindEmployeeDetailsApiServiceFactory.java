package io.swagger.api.factories;

import io.swagger.api.FindEmployeeDetailsApiService;
import io.swagger.api.impl.FindEmployeeDetailsApiServiceImpl;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2018-06-07T10:54:23.419Z")
public class FindEmployeeDetailsApiServiceFactory {

   private final static FindEmployeeDetailsApiService service = new FindEmployeeDetailsApiServiceImpl();

   public static FindEmployeeDetailsApiService getFindEmployeeDetailsApi()
   {
      return service;
   }
}
