
# Employee

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**firstName** | **String** | Employee First Name |  [optional]
**lastName** | **String** | Employee Last Name |  [optional]



