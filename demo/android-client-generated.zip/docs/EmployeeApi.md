# EmployeeApi

All URIs are relative to *https://virtserver.swaggerhub.com/Consultant_Demo/Employee/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getEmployeeDetails**](EmployeeApi.md#getEmployeeDetails) | **GET** /findEmployeeDetails/{employeeId} | Find employee by ID


<a name="getEmployeeDetails"></a>
# **getEmployeeDetails**
> Employee getEmployeeDetails(employeeId)

Find employee by ID

Returns a single Employee

### Example
```java
// Import classes:
//import io.swagger.client.api.EmployeeApi;

EmployeeApi apiInstance = new EmployeeApi();
Long employeeId = 789L; // Long | ID of Employee to return
try {
    Employee result = apiInstance.getEmployeeDetails(employeeId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EmployeeApi#getEmployeeDetails");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **employeeId** | **Long**| ID of Employee to return |

### Return type

[**Employee**](Employee.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

